%Lyle Olsen
%Assignment 1
%9/10/16


%Did not finish this problem
function [blurredIm] = BlurImage(oriIm)

%read the 4X4 block, get the average and then put average in each pixel in
%4x4 block

howMany = numel(oriIm);
for i=1:howMany,
    for j=1:4,
        
    end
end


blurredIm = 0;
end